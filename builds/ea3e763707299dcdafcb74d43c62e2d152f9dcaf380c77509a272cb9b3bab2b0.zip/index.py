import json
import os
import boto3
from urllib.parse import urlparse
import uuid

# Initialize AWS clients for S3 and MediaConvert
s3_client = boto3.client('s3')
mediaconvert_client = boto3.client('mediaconvert')

def lambda_handler(event, context):
    # Log the event to inspect its structure
    print(f"Received event: {json.dumps(event)}")
    # Get the MediaConvert endpoint for the specified region
    region = os.environ['AWS_REGION']
    mediaconvert_endpoint = get_mediaconvert_endpoint(region)
    
    # Destination bucket and MediaConvert role from environment variables
    destination_bucket = os.environ['DESTINATION_BUCKET']
    mediaconvert_role = os.environ['MEDIACONVERT_ROLE']
    
    # Process each record in the SQS event
    for record in event['Records']:
        try:
            # Parse the message body from the SQS record
            message_body = json.loads(record['body'])
            
            # Extract S3 information from the message
            s3_info = message_body['Records'][0]['s3']
            source_bucket = s3_info['bucket']['name']
            s3_key = s3_info['object']['key']
            
            # Identify the folder name from the S3 key (first part of the key)
            folder_name = s3_key.split('/')[0]
            
            # Try to load the corresponding JSON configuration from S3
            config_key = f"transcoder_config/{folder_name}.json"
            try:
                job_settings = load_json_config(source_bucket, config_key)
            except s3_client.exceptions.NoSuchKey:
                print(f"Configuration file for {folder_name} not found. Using default.json.")
                config_key = "transcoder_config/default.json"
                job_settings = load_json_config(source_bucket, config_key)
            
            # Modify the MediaConvert job settings with the input file and output paths
            source_s3 = f"s3://{source_bucket}/{s3_key}"
            modify_job_settings(job_settings, source_s3, folder_name, destination_bucket)
            
            # Metadata for the MediaConvert job
            job_metadata_dict = {
                'assetID': str(uuid.uuid4()),
                'application': 'MediaConvertApp',
                'input': source_s3,
                'settings': f"{folder_name}.json"
            }
            
            # Create the MediaConvert job
            mediaconvert_client.create_job(
                Role=mediaconvert_role,
                UserMetadata=job_metadata_dict,
                Settings=job_settings,
                Endpoint=mediaconvert_endpoint
            )
            print(f"Job created for {source_s3} with output in {destination_bucket}/{folder_name}/")
        
        except Exception as error:
            # Log the error and consider sending the message to a Dead Letter Queue (DLQ)
            print(f"Error creating MediaConvert job: {str(error)}")
            raise  # Re-throw the error to let Lambda's DLQ (if configured) handle it

    return {
        'statusCode': 200,
        'body': 'SQS processing completed successfully!'
    }

def get_mediaconvert_endpoint(region):
    """Retrieve the MediaConvert endpoint for the specified region."""
    mediaconvert_client = boto3.client('mediaconvert', region_name=region)
    endpoints = mediaconvert_client.describe_endpoints()
    return endpoints['Endpoints'][0]['Url']

def load_json_config(bucket, key):
    """Load the JSON configuration file from S3."""
    response = s3_client.get_object(Bucket=bucket, Key=key)
    config_json = response['Body'].read().decode('utf-8')
    return json.loads(config_json)

def modify_job_settings(job_settings, source_s3, folder_name, destination_bucket):
    """Modify the MediaConvert job settings with input and output configurations."""
    job_settings['Inputs'][0]['FileInput'] = source_s3
    
    # Construct the destination path in S3 using the folder name
    output_base = f"s3://{destination_bucket}/{folder_name}/"
    
    # Update the destination in all output groups
    for output_group in job_settings['OutputGroups']:
        output_group_type = output_group['OutputGroupSettings']['Type']
        output_group_settings_key = get_output_group_settings_key(output_group_type)
        
        if output_group_settings_key:
            output_group['OutputGroupSettings'][output_group_settings_key]['Destination'] = \
                output_base + urlparse(output_group['OutputGroupSettings'][output_group_settings_key]['Destination']).path
        else:
            raise ValueError(f"Unknown Output Group Type: {output_group_type}")

def get_output_group_settings_key(output_group_type):
    """Map the output group type to the corresponding configuration key."""
    output_group_type_dict = {
        'HLS_GROUP_SETTINGS': 'HlsGroupSettings',
        'FILE_GROUP_SETTINGS': 'FileGroupSettings',
        'CMAF_GROUP_SETTINGS': 'CmafGroupSettings',
        'DASH_ISO_GROUP_SETTINGS': 'DashIsoGroupSettings',
        'MS_SMOOTH_GROUP_SETTINGS': 'MsSmoothGroupSettings'
    }
    return output_group_type_dict.get(output_group_type)
